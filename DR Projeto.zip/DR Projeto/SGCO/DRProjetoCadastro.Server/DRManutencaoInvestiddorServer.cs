﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DR.Lib.RegraNegocio;

namespace DRProjetoCadastro.BLL
{
    public class DRManutencaoInvestiddorServer : DRDataBase
    {
    }
}
