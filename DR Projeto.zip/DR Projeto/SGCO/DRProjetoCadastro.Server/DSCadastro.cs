﻿namespace DRProjetoCadastro.BLL
{
    
    
    public partial class DSCadastro {
        partial class DRAtividadeDataTable
        {
        }
    }
}
