﻿namespace DRProjetoCadastro.BLL
{
    
    
    public partial class DSConfigPref {
        partial class PreferenciaDataTable
        {
        }
    }
}
