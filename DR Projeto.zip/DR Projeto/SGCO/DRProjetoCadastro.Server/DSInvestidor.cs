﻿namespace DRProjetoCadastro.BLL
{
    
    
    public partial class DSInvestidor {
        partial class DRPAGAMENTOINVESTIDORDataTable
        {
        }
    }
}
namespace DRProjetoCadastro.BLL.DSInvestidorTableAdapters
{
    
    
    public partial class DSInvestidor {
    }
}
