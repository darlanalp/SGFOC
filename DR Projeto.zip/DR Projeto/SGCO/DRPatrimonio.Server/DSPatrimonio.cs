﻿namespace DRPatrimonio.Server {
    
    
    public partial class DSPatrimonio {
    }
}
