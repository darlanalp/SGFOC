﻿namespace DRRelatorios.Rel.DataSet1TableAdapters
{
}
namespace DRRelatorios.Rel.DataSet1TableAdapters
{
}
namespace DRRelatorios.Rel.DataSet1TableAdapters
{
}
namespace DRRelatorios.Rel.DataSet1TableAdapters
{
    
    
    public partial class DSRelatorio {
    }
}
namespace DRRelatorios.Rel {
    
    
    public partial class DataSet1 {
        partial class DRENTRADA_DESPESADataTable
        {
        }
    
        partial class DRACOMPRESUMIDODataTable
        {
        }
    }
}
