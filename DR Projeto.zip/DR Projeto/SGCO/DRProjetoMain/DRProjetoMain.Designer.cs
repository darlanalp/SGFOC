﻿namespace DRProjetoMain
{
    partial class SGFOC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DR.Utils.PolicyMaster policyMaster27 = new DR.Utils.PolicyMaster();
            DR.Utils.Policy policy37 = new DR.Utils.Policy();
            DR.Utils.Policy policy38 = new DR.Utils.Policy();
            DR.Utils.Policy policy39 = new DR.Utils.Policy();
            DR.Utils.PolicyMaster policyMaster28 = new DR.Utils.PolicyMaster();
            DR.Utils.Policy policy40 = new DR.Utils.Policy();
            DR.Utils.Policy policy41 = new DR.Utils.Policy();
            DR.Utils.Policy policy42 = new DR.Utils.Policy();
            DR.Utils.PolicyMaster policyMaster29 = new DR.Utils.PolicyMaster();
            DR.Utils.PolicyMaster policyMaster30 = new DR.Utils.PolicyMaster();
            DR.Utils.Policy policy43 = new DR.Utils.Policy();
            DR.Utils.Policy policy44 = new DR.Utils.Policy();
            DR.Utils.Policy policy45 = new DR.Utils.Policy();
            DR.Utils.PolicyMaster policyMaster31 = new DR.Utils.PolicyMaster();
            DR.Utils.PolicyMaster policyMaster32 = new DR.Utils.PolicyMaster();
            DR.Utils.Policy policy46 = new DR.Utils.Policy();
            DR.Utils.Policy policy47 = new DR.Utils.Policy();
            DR.Utils.Policy policy48 = new DR.Utils.Policy();
            DR.Utils.PolicyMaster policyMaster33 = new DR.Utils.PolicyMaster();
            DR.Utils.Policy policy49 = new DR.Utils.Policy();
            DR.Utils.Policy policy50 = new DR.Utils.Policy();
            DR.Utils.Policy policy51 = new DR.Utils.Policy();
            DR.Utils.PolicyMaster policyMaster34 = new DR.Utils.PolicyMaster();
            DR.Utils.Policy policy52 = new DR.Utils.Policy();
            DR.Utils.Policy policy53 = new DR.Utils.Policy();
            DR.Utils.Policy policy54 = new DR.Utils.Policy();
            DR.Utils.PolicyMaster policyMaster35 = new DR.Utils.PolicyMaster();
            DR.Utils.Policy policy55 = new DR.Utils.Policy();
            DR.Utils.Policy policy56 = new DR.Utils.Policy();
            DR.Utils.Policy policy57 = new DR.Utils.Policy();
            DR.Utils.PolicyMaster policyMaster36 = new DR.Utils.PolicyMaster();
            DR.Utils.Policy policy58 = new DR.Utils.Policy();
            DR.Utils.Policy policy59 = new DR.Utils.Policy();
            DR.Utils.Policy policy60 = new DR.Utils.Policy();
            DR.Utils.PolicyMaster policyMaster37 = new DR.Utils.PolicyMaster();
            DR.Utils.Policy policy61 = new DR.Utils.Policy();
            DR.Utils.Policy policy62 = new DR.Utils.Policy();
            DR.Utils.Policy policy63 = new DR.Utils.Policy();
            DR.Utils.PolicyMaster policyMaster38 = new DR.Utils.PolicyMaster();
            DR.Utils.Policy policy64 = new DR.Utils.Policy();
            DR.Utils.Policy policy65 = new DR.Utils.Policy();
            DR.Utils.Policy policy66 = new DR.Utils.Policy();
            DR.Utils.PolicyMaster policyMaster39 = new DR.Utils.PolicyMaster();
            DR.Utils.Policy policy67 = new DR.Utils.Policy();
            DR.Utils.Policy policy68 = new DR.Utils.Policy();
            DR.Utils.Policy policy69 = new DR.Utils.Policy();
            DR.Utils.PolicyMaster policyMaster40 = new DR.Utils.PolicyMaster();
            DR.Utils.PolicyMaster policyMaster41 = new DR.Utils.PolicyMaster();
            DR.Utils.PolicyMaster policyMaster42 = new DR.Utils.PolicyMaster();
            DR.Utils.PolicyMaster policyMaster43 = new DR.Utils.PolicyMaster();
            DR.Utils.PolicyMaster policyMaster44 = new DR.Utils.PolicyMaster();
            DR.Utils.PolicyMaster policyMaster45 = new DR.Utils.PolicyMaster();
            DR.Utils.PolicyMaster policyMaster46 = new DR.Utils.PolicyMaster();
            DR.Utils.PolicyMaster policyMaster47 = new DR.Utils.PolicyMaster();
            DR.Utils.PolicyMaster policyMaster48 = new DR.Utils.PolicyMaster();
            DR.Utils.PolicyMaster policyMaster49 = new DR.Utils.PolicyMaster();
            DR.Utils.PolicyMaster policyMaster50 = new DR.Utils.PolicyMaster();
            DR.Utils.Policy policy70 = new DR.Utils.Policy();
            DR.Utils.Policy policy71 = new DR.Utils.Policy();
            DR.Utils.Policy policy72 = new DR.Utils.Policy();
            DR.Utils.PolicyMaster policyMaster51 = new DR.Utils.PolicyMaster();
            DR.Utils.PolicyMaster policyMaster52 = new DR.Utils.PolicyMaster();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SGFOC));
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.sistemaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selecionarObraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.loginToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.usuáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.backupCópiaDeSegurançaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.empresaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.forToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ObraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cronogramaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.cotasDaObraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.investidoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.patrimônioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lançamentosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.despesasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.despesaPorEtapaAtividadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.rendimentosMensalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gerencialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gráficoPrincipalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relatóriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.etapasAtividadesCadastradasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.acompanhamentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.despesaPorEtapaAtividadeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.conferenciaDeDespesasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.acompanhamentoInvestidorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.investidoresToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.extratoPagamentoInvestidorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cotasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.patrimôniosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ajudaManualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contatoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlAtalho = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.menuStrip2.SuspendLayout();
            this.pnlAtalho.SuspendLayout();
            this.SuspendLayout();
            // 
            // drControleFormControl1
            // 
            policyMaster27.Caption = "Obra";
            policyMaster27.Name = "DRCadProjeto-1";
            policy37.Caption = "Incluir";
            policy37.Name = "Incluir";
            policy37.Tag = 1;
            policy38.Caption = "Alterar";
            policy38.Name = "Alterar";
            policy38.Tag = 2;
            policy39.Caption = "Excluir";
            policy39.Name = "Excluir";
            policy39.Tag = 3;
            policyMaster27.SegurancaItem.Add(policy37);
            policyMaster27.SegurancaItem.Add(policy38);
            policyMaster27.SegurancaItem.Add(policy39);
            policyMaster27.Tag = 1;
            policyMaster28.Caption = "Empresa";
            policyMaster28.Name = "DRCadEmpresa-800001";
            policy40.Caption = "Incluir";
            policy40.Name = "Incluir";
            policy40.Tag = 1;
            policy41.Caption = "Alterar";
            policy41.Name = "Alterar";
            policy41.Tag = 2;
            policy42.Caption = "Excluir";
            policy42.Name = "Excluir";
            policy42.Tag = 3;
            policyMaster28.SegurancaItem.Add(policy40);
            policyMaster28.SegurancaItem.Add(policy41);
            policyMaster28.SegurancaItem.Add(policy42);
            policyMaster28.Tag = 800001;
            policyMaster29.Caption = "Usuários";
            policyMaster29.Name = "DRCadUser-13";
            policyMaster29.Tag = 13;
            policyMaster30.Caption = "Fornecedor";
            policyMaster30.Name = "DRCadForncedor-2";
            policy43.Caption = "Incluir";
            policy43.Name = "Incluir";
            policy43.Tag = 1;
            policy44.Caption = "Alterar";
            policy44.Name = "Alterar";
            policy44.Tag = 2;
            policy45.Caption = "Excluir";
            policy45.Name = "Excluir";
            policy45.Tag = 3;
            policyMaster30.SegurancaItem.Add(policy43);
            policyMaster30.SegurancaItem.Add(policy44);
            policyMaster30.SegurancaItem.Add(policy45);
            policyMaster30.Tag = 2;
            policyMaster31.Caption = "Cronograma Etapa/Atividade";
            policyMaster31.Name = "DRCronograma3";
            policyMaster31.Tag = 3;
            policyMaster32.Caption = "Manutenção Investidor";
            policyMaster32.Name = "DRManutencaoInvestidor4";
            policy46.Caption = "Incluir";
            policy46.Name = "Incluir";
            policy46.Tag = 1;
            policy47.Caption = "Alterar";
            policy47.Name = "Alterar";
            policy47.Tag = 2;
            policy48.Caption = "Excluir";
            policy48.Name = "Excluir";
            policy48.Tag = 3;
            policyMaster32.SegurancaItem.Add(policy46);
            policyMaster32.SegurancaItem.Add(policy47);
            policyMaster32.SegurancaItem.Add(policy48);
            policyMaster32.Tag = 4;
            policyMaster33.Caption = "Despesa Etapa/Atividade";
            policyMaster33.Name = "DRFormDespesa-5";
            policy49.Caption = "Incluir";
            policy49.Name = "Incluir";
            policy49.Tag = 1;
            policy50.Caption = "Alterar";
            policy50.Name = "Alterar";
            policy50.Tag = 2;
            policy51.Caption = "Excluir";
            policy51.Name = "Excluir";
            policy51.Tag = 3;
            policyMaster33.SegurancaItem.Add(policy49);
            policyMaster33.SegurancaItem.Add(policy50);
            policyMaster33.SegurancaItem.Add(policy51);
            policyMaster33.Tag = 5;
            policyMaster34.Caption = "Etapa";
            policyMaster34.Name = "DRCadEtapa-6";
            policy52.Caption = "Incluir";
            policy52.Name = "Incluir";
            policy52.Tag = 1;
            policy53.Caption = "Alterar";
            policy53.Name = "Alterar";
            policy53.Tag = 2;
            policy54.Caption = "Excluir";
            policy54.Name = "Excluir";
            policy54.Tag = 3;
            policyMaster34.SegurancaItem.Add(policy52);
            policyMaster34.SegurancaItem.Add(policy53);
            policyMaster34.SegurancaItem.Add(policy54);
            policyMaster34.Tag = 6;
            policyMaster35.Caption = "Atividade";
            policyMaster35.Name = "DRCadAtividade-7";
            policy55.Caption = "Incluir";
            policy55.Name = "Incluir";
            policy55.Tag = 1;
            policy56.Caption = "Alterar";
            policy56.Name = "Alterar";
            policy56.Tag = 2;
            policy57.Caption = "Excluir";
            policy57.Name = "Excluir";
            policy57.Tag = 3;
            policyMaster35.SegurancaItem.Add(policy55);
            policyMaster35.SegurancaItem.Add(policy56);
            policyMaster35.SegurancaItem.Add(policy57);
            policyMaster35.Tag = 7;
            policyMaster36.Caption = "Investidor";
            policyMaster36.Name = "DRCadInvestidor-8";
            policy58.Caption = "Incluir";
            policy58.Name = "Incluir";
            policy58.Tag = 1;
            policy59.Caption = "Alterar";
            policy59.Name = "Alterar";
            policy59.Tag = 2;
            policy60.Caption = "Excluir";
            policy60.Name = "Excluir";
            policy60.Tag = 3;
            policyMaster36.SegurancaItem.Add(policy58);
            policyMaster36.SegurancaItem.Add(policy59);
            policyMaster36.SegurancaItem.Add(policy60);
            policyMaster36.Tag = 8;
            policyMaster37.Caption = "Lançamento Financeiro Investidor";
            policyMaster37.Name = "DRInvestidorLan-9";
            policy61.Caption = "Incluir";
            policy61.Name = "Incluir";
            policy61.Tag = 1;
            policy62.Caption = "Alterar";
            policy62.Name = "Alterar";
            policy62.Tag = 2;
            policy63.Caption = "Excluir";
            policy63.Name = "Excluir";
            policy63.Tag = 3;
            policyMaster37.SegurancaItem.Add(policy61);
            policyMaster37.SegurancaItem.Add(policy62);
            policyMaster37.SegurancaItem.Add(policy63);
            policyMaster37.Tag = 9;
            policyMaster38.Caption = "Cadastro de Patrimônios";
            policyMaster38.Name = "DRCadPatrimonio-10";
            policy64.Caption = "Incluir";
            policy64.Name = "Incluir";
            policy64.Tag = 1;
            policy65.Caption = "Alterar";
            policy65.Name = "Alterar";
            policy65.Tag = 2;
            policy66.Caption = "Excluir";
            policy66.Name = "Excluir";
            policy66.Tag = 3;
            policyMaster38.SegurancaItem.Add(policy64);
            policyMaster38.SegurancaItem.Add(policy65);
            policyMaster38.SegurancaItem.Add(policy66);
            policyMaster38.Tag = 10;
            policyMaster39.Caption = null;
            policyMaster39.Name = "DRCadRendimento-11";
            policy67.Caption = "Incluir";
            policy67.Name = "Incluir";
            policy67.Tag = 1;
            policy68.Caption = "Alterar";
            policy68.Name = "Alterar";
            policy68.Tag = 2;
            policy69.Caption = "Excluir";
            policy69.Name = "Excluir";
            policy69.Tag = 3;
            policyMaster39.SegurancaItem.Add(policy67);
            policyMaster39.SegurancaItem.Add(policy68);
            policyMaster39.SegurancaItem.Add(policy69);
            policyMaster39.Tag = 11;
            policyMaster40.Caption = null;
            policyMaster40.Name = "DRRelatorioEtapaAtividade-12";
            policyMaster40.Tag = 12;
            policyMaster41.Caption = null;
            policyMaster41.Name = "DRFormRelAcompanhamento-13";
            policyMaster41.Tag = 13;
            policyMaster42.Caption = null;
            policyMaster42.Name = "DRFORMRelDespesaAtividade-14";
            policyMaster42.Tag = 14;
            policyMaster43.Caption = null;
            policyMaster43.Name = "DRFormConferenciaDespesas-15";
            policyMaster43.Tag = 15;
            policyMaster44.Caption = null;
            policyMaster44.Name = "DRFormRelAcompInvestidor-16";
            policyMaster44.Tag = 16;
            policyMaster45.Caption = null;
            policyMaster45.Name = "DRInvestidor17";
            policyMaster45.Tag = 17;
            policyMaster46.Caption = null;
            policyMaster46.Name = "DRRelExtratoPagInvestidor18";
            policyMaster46.Tag = 18;
            policyMaster47.Caption = null;
            policyMaster47.Name = "DRFormRelPatrimonio-19";
            policyMaster47.Tag = 19;
            policyMaster48.Caption = null;
            policyMaster48.Name = "DRGraficoPricinpal-20";
            policyMaster48.Tag = 20;
            policyMaster49.Caption = null;
            policyMaster49.Name = "DRVisualizaTotalizadorCronograma-21";
            policyMaster49.Tag = 21;
            policyMaster50.Caption = null;
            policyMaster50.Name = "DRCadCota-22";
            policy70.Caption = "Incluir";
            policy70.Name = "Incluir";
            policy70.Tag = 1;
            policy71.Caption = "Alterar";
            policy71.Name = "Alterar";
            policy71.Tag = 2;
            policy72.Caption = "Excluir";
            policy72.Name = "Excluir";
            policy72.Tag = 3;
            policyMaster50.SegurancaItem.Add(policy70);
            policyMaster50.SegurancaItem.Add(policy71);
            policyMaster50.SegurancaItem.Add(policy72);
            policyMaster50.Tag = 22;
            policyMaster51.Caption = "DRRelCotas";
            policyMaster51.Name = "DRRelCotas";
            policyMaster51.Tag = 23;
            policyMaster52.Caption = "DRBackup";
            policyMaster52.Name = "DRBackup";
            policyMaster52.Tag = 24;
            this.drControleFormControl1.DR.Add(policyMaster27);
            this.drControleFormControl1.DR.Add(policyMaster28);
            this.drControleFormControl1.DR.Add(policyMaster29);
            this.drControleFormControl1.DR.Add(policyMaster30);
            this.drControleFormControl1.DR.Add(policyMaster31);
            this.drControleFormControl1.DR.Add(policyMaster32);
            this.drControleFormControl1.DR.Add(policyMaster33);
            this.drControleFormControl1.DR.Add(policyMaster34);
            this.drControleFormControl1.DR.Add(policyMaster35);
            this.drControleFormControl1.DR.Add(policyMaster36);
            this.drControleFormControl1.DR.Add(policyMaster37);
            this.drControleFormControl1.DR.Add(policyMaster38);
            this.drControleFormControl1.DR.Add(policyMaster39);
            this.drControleFormControl1.DR.Add(policyMaster40);
            this.drControleFormControl1.DR.Add(policyMaster41);
            this.drControleFormControl1.DR.Add(policyMaster42);
            this.drControleFormControl1.DR.Add(policyMaster43);
            this.drControleFormControl1.DR.Add(policyMaster44);
            this.drControleFormControl1.DR.Add(policyMaster45);
            this.drControleFormControl1.DR.Add(policyMaster46);
            this.drControleFormControl1.DR.Add(policyMaster47);
            this.drControleFormControl1.DR.Add(policyMaster48);
            this.drControleFormControl1.DR.Add(policyMaster49);
            this.drControleFormControl1.DR.Add(policyMaster50);
            this.drControleFormControl1.DR.Add(policyMaster51);
            this.drControleFormControl1.DR.Add(policyMaster52);
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sistemaToolStripMenuItem,
            this.loginToolStripMenuItem,
            this.lançamentosToolStripMenuItem,
            this.gerencialToolStripMenuItem,
            this.relatóriosToolStripMenuItem,
            this.ajudaManualToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(872, 24);
            this.menuStrip2.TabIndex = 5;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // sistemaToolStripMenuItem
            // 
            this.sistemaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.selecionarObraToolStripMenuItem,
            this.toolStripSeparator3,
            this.loginToolStripMenuItem1,
            this.usuáriosToolStripMenuItem,
            this.toolStripSeparator2,
            this.backupCópiaDeSegurançaToolStripMenuItem});
            this.sistemaToolStripMenuItem.Name = "sistemaToolStripMenuItem";
            this.sistemaToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.sistemaToolStripMenuItem.Text = "Sistema";
            // 
            // selecionarObraToolStripMenuItem
            // 
            this.selecionarObraToolStripMenuItem.Name = "selecionarObraToolStripMenuItem";
            this.selecionarObraToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.selecionarObraToolStripMenuItem.Text = "Selecionar Obra";
            this.selecionarObraToolStripMenuItem.Click += new System.EventHandler(this.selecionarObraToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(223, 6);
            // 
            // loginToolStripMenuItem1
            // 
            this.loginToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("loginToolStripMenuItem1.Image")));
            this.loginToolStripMenuItem1.Name = "loginToolStripMenuItem1";
            this.loginToolStripMenuItem1.Size = new System.Drawing.Size(226, 22);
            this.loginToolStripMenuItem1.Text = "Login/Lgout";
            this.loginToolStripMenuItem1.Click += new System.EventHandler(this.loginToolStripMenuItem1_Click);
            // 
            // usuáriosToolStripMenuItem
            // 
            this.usuáriosToolStripMenuItem.Image = global::SGFOC.Properties.Resources.access;
            this.usuáriosToolStripMenuItem.Name = "usuáriosToolStripMenuItem";
            this.usuáriosToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.usuáriosToolStripMenuItem.Tag = "";
            this.usuáriosToolStripMenuItem.Text = "Usuários";
            this.usuáriosToolStripMenuItem.Click += new System.EventHandler(this.usuáriosToolStripMenuItem_Click_1);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(223, 6);
            // 
            // backupCópiaDeSegurançaToolStripMenuItem
            // 
            this.backupCópiaDeSegurançaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("backupCópiaDeSegurançaToolStripMenuItem.Image")));
            this.backupCópiaDeSegurançaToolStripMenuItem.Name = "backupCópiaDeSegurançaToolStripMenuItem";
            this.backupCópiaDeSegurançaToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.backupCópiaDeSegurançaToolStripMenuItem.Tag = "24";
            this.backupCópiaDeSegurançaToolStripMenuItem.Text = "Backup(Cópia de Segurança)";
            this.backupCópiaDeSegurançaToolStripMenuItem.Click += new System.EventHandler(this.backupCópiaDeSegurançaToolStripMenuItem_Click);
            // 
            // loginToolStripMenuItem
            // 
            this.loginToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.empresaToolStripMenuItem1,
            this.forToolStripMenuItem,
            this.toolStripSeparator1,
            this.ObraToolStripMenuItem,
            this.cronogramaToolStripMenuItem,
            this.toolStripSeparator4,
            this.cotasDaObraToolStripMenuItem,
            this.investidoresToolStripMenuItem,
            this.toolStripSeparator10,
            this.patrimônioToolStripMenuItem});
            this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            this.loginToolStripMenuItem.Size = new System.Drawing.Size(86, 20);
            this.loginToolStripMenuItem.Text = "Manutenção";
            // 
            // empresaToolStripMenuItem1
            // 
            this.empresaToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("empresaToolStripMenuItem1.Image")));
            this.empresaToolStripMenuItem1.Name = "empresaToolStripMenuItem1";
            this.empresaToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.empresaToolStripMenuItem1.Tag = "800001";
            this.empresaToolStripMenuItem1.Text = "Empresa";
            this.empresaToolStripMenuItem1.Click += new System.EventHandler(this.empresaToolStripMenuItem1_Click);
            // 
            // forToolStripMenuItem
            // 
            this.forToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("forToolStripMenuItem.Image")));
            this.forToolStripMenuItem.Name = "forToolStripMenuItem";
            this.forToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.forToolStripMenuItem.Tag = "2";
            this.forToolStripMenuItem.Text = "Fornecedor";
            this.forToolStripMenuItem.Click += new System.EventHandler(this.forToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // ObraToolStripMenuItem
            // 
            this.ObraToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ObraToolStripMenuItem.Image")));
            this.ObraToolStripMenuItem.Name = "ObraToolStripMenuItem";
            this.ObraToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ObraToolStripMenuItem.Tag = "1";
            this.ObraToolStripMenuItem.Text = "Obra";
            this.ObraToolStripMenuItem.Click += new System.EventHandler(this.ObraToolStripMenuItem_Click);
            // 
            // cronogramaToolStripMenuItem
            // 
            this.cronogramaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cronogramaToolStripMenuItem.Image")));
            this.cronogramaToolStripMenuItem.Name = "cronogramaToolStripMenuItem";
            this.cronogramaToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.cronogramaToolStripMenuItem.Tag = "3";
            this.cronogramaToolStripMenuItem.Text = "Cronograma";
            this.cronogramaToolStripMenuItem.Click += new System.EventHandler(this.cronogramaToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(149, 6);
            // 
            // cotasDaObraToolStripMenuItem
            // 
            this.cotasDaObraToolStripMenuItem.Image = global::SGFOC.Properties.Resources.arrow_in;
            this.cotasDaObraToolStripMenuItem.Name = "cotasDaObraToolStripMenuItem";
            this.cotasDaObraToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.cotasDaObraToolStripMenuItem.Tag = "22";
            this.cotasDaObraToolStripMenuItem.Text = "Cotas da Obra";
            this.cotasDaObraToolStripMenuItem.Click += new System.EventHandler(this.cotasDaObraToolStripMenuItem_Click);
            // 
            // investidoresToolStripMenuItem
            // 
            this.investidoresToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("investidoresToolStripMenuItem.Image")));
            this.investidoresToolStripMenuItem.Name = "investidoresToolStripMenuItem";
            this.investidoresToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.investidoresToolStripMenuItem.Tag = "8";
            this.investidoresToolStripMenuItem.Text = "Investidores";
            this.investidoresToolStripMenuItem.Click += new System.EventHandler(this.investidoresToolStripMenuItem_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(149, 6);
            // 
            // patrimônioToolStripMenuItem
            // 
            this.patrimônioToolStripMenuItem.Image = global::SGFOC.Properties.Resources.inventory_star_24;
            this.patrimônioToolStripMenuItem.Name = "patrimônioToolStripMenuItem";
            this.patrimônioToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.patrimônioToolStripMenuItem.Tag = "10";
            this.patrimônioToolStripMenuItem.Text = "Patrimônios";
            this.patrimônioToolStripMenuItem.Click += new System.EventHandler(this.patrimônioToolStripMenuItem_Click);
            // 
            // lançamentosToolStripMenuItem
            // 
            this.lançamentosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.despesasToolStripMenuItem,
            this.despesaPorEtapaAtividadeToolStripMenuItem,
            this.toolStripSeparator7,
            this.rendimentosMensalToolStripMenuItem});
            this.lançamentosToolStripMenuItem.Name = "lançamentosToolStripMenuItem";
            this.lançamentosToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.lançamentosToolStripMenuItem.Text = "Lançamentos";
            // 
            // despesasToolStripMenuItem
            // 
            this.despesasToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("despesasToolStripMenuItem.Image")));
            this.despesasToolStripMenuItem.Name = "despesasToolStripMenuItem";
            this.despesasToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.despesasToolStripMenuItem.Tag = "5";
            this.despesasToolStripMenuItem.Text = "Despesas Geral";
            this.despesasToolStripMenuItem.Click += new System.EventHandler(this.despesasToolStripMenuItem_Click);
            // 
            // despesaPorEtapaAtividadeToolStripMenuItem
            // 
            this.despesaPorEtapaAtividadeToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("despesaPorEtapaAtividadeToolStripMenuItem.Image")));
            this.despesaPorEtapaAtividadeToolStripMenuItem.Name = "despesaPorEtapaAtividadeToolStripMenuItem";
            this.despesaPorEtapaAtividadeToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.despesaPorEtapaAtividadeToolStripMenuItem.Tag = "5";
            this.despesaPorEtapaAtividadeToolStripMenuItem.Text = "Despesa por Etapa/Atividade";
            this.despesaPorEtapaAtividadeToolStripMenuItem.Click += new System.EventHandler(this.despesaPorEtapaAtividadeToolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(222, 6);
            // 
            // rendimentosMensalToolStripMenuItem
            // 
            this.rendimentosMensalToolStripMenuItem.Image = global::SGFOC.Properties.Resources.piggybank_add_32;
            this.rendimentosMensalToolStripMenuItem.Name = "rendimentosMensalToolStripMenuItem";
            this.rendimentosMensalToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.rendimentosMensalToolStripMenuItem.Tag = "11";
            this.rendimentosMensalToolStripMenuItem.Text = "Rendimentos Mensal";
            this.rendimentosMensalToolStripMenuItem.Click += new System.EventHandler(this.rendimentosMensalToolStripMenuItem_Click);
            // 
            // gerencialToolStripMenuItem
            // 
            this.gerencialToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gráficoPrincipalToolStripMenuItem});
            this.gerencialToolStripMenuItem.Name = "gerencialToolStripMenuItem";
            this.gerencialToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.gerencialToolStripMenuItem.Text = "Gerencial";
            // 
            // gráficoPrincipalToolStripMenuItem
            // 
            this.gráficoPrincipalToolStripMenuItem.Image = global::SGFOC.Properties.Resources.GráficoPricipal;
            this.gráficoPrincipalToolStripMenuItem.Name = "gráficoPrincipalToolStripMenuItem";
            this.gráficoPrincipalToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.gráficoPrincipalToolStripMenuItem.Tag = "20";
            this.gráficoPrincipalToolStripMenuItem.Text = "Gráfico Principal";
            this.gráficoPrincipalToolStripMenuItem.Click += new System.EventHandler(this.gráficoPrincipalToolStripMenuItem_Click);
            // 
            // relatóriosToolStripMenuItem
            // 
            this.relatóriosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.etapasAtividadesCadastradasToolStripMenuItem,
            this.toolStripSeparator8,
            this.acompanhamentoToolStripMenuItem,
            this.toolStripSeparator9,
            this.despesaPorEtapaAtividadeToolStripMenuItem1,
            this.conferenciaDeDespesasToolStripMenuItem,
            this.toolStripSeparator5,
            this.acompanhamentoInvestidorToolStripMenuItem,
            this.toolStripSeparator11,
            this.investidoresToolStripMenuItem1,
            this.extratoPagamentoInvestidorToolStripMenuItem,
            this.cotasToolStripMenuItem,
            this.toolStripSeparator6,
            this.patrimôniosToolStripMenuItem});
            this.relatóriosToolStripMenuItem.Name = "relatóriosToolStripMenuItem";
            this.relatóriosToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.relatóriosToolStripMenuItem.Text = "Relatórios";
            // 
            // etapasAtividadesCadastradasToolStripMenuItem
            // 
            this.etapasAtividadesCadastradasToolStripMenuItem.Name = "etapasAtividadesCadastradasToolStripMenuItem";
            this.etapasAtividadesCadastradasToolStripMenuItem.Size = new System.Drawing.Size(268, 22);
            this.etapasAtividadesCadastradasToolStripMenuItem.Tag = "12";
            this.etapasAtividadesCadastradasToolStripMenuItem.Text = "Etapas/Atividades Cadastradas";
            this.etapasAtividadesCadastradasToolStripMenuItem.Click += new System.EventHandler(this.etapasAtividadesCadastradasToolStripMenuItem_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(265, 6);
            // 
            // acompanhamentoToolStripMenuItem
            // 
            this.acompanhamentoToolStripMenuItem.Name = "acompanhamentoToolStripMenuItem";
            this.acompanhamentoToolStripMenuItem.Size = new System.Drawing.Size(268, 22);
            this.acompanhamentoToolStripMenuItem.Tag = "13";
            this.acompanhamentoToolStripMenuItem.Text = "Acompanhamento da Obra";
            this.acompanhamentoToolStripMenuItem.Click += new System.EventHandler(this.acompanhamentoToolStripMenuItem_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(265, 6);
            // 
            // despesaPorEtapaAtividadeToolStripMenuItem1
            // 
            this.despesaPorEtapaAtividadeToolStripMenuItem1.Name = "despesaPorEtapaAtividadeToolStripMenuItem1";
            this.despesaPorEtapaAtividadeToolStripMenuItem1.Size = new System.Drawing.Size(268, 22);
            this.despesaPorEtapaAtividadeToolStripMenuItem1.Tag = "14";
            this.despesaPorEtapaAtividadeToolStripMenuItem1.Text = "Despesa Por Etapa/Atividade";
            this.despesaPorEtapaAtividadeToolStripMenuItem1.Click += new System.EventHandler(this.despesaPorEtapaAtividadeToolStripMenuItem1_Click);
            // 
            // conferenciaDeDespesasToolStripMenuItem
            // 
            this.conferenciaDeDespesasToolStripMenuItem.Name = "conferenciaDeDespesasToolStripMenuItem";
            this.conferenciaDeDespesasToolStripMenuItem.Size = new System.Drawing.Size(268, 22);
            this.conferenciaDeDespesasToolStripMenuItem.Tag = "15";
            this.conferenciaDeDespesasToolStripMenuItem.Text = "Conferencia de Despesas";
            this.conferenciaDeDespesasToolStripMenuItem.Click += new System.EventHandler(this.conferenciaDeDespesasToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(265, 6);
            // 
            // acompanhamentoInvestidorToolStripMenuItem
            // 
            this.acompanhamentoInvestidorToolStripMenuItem.Name = "acompanhamentoInvestidorToolStripMenuItem";
            this.acompanhamentoInvestidorToolStripMenuItem.Size = new System.Drawing.Size(268, 22);
            this.acompanhamentoInvestidorToolStripMenuItem.Tag = "16";
            this.acompanhamentoInvestidorToolStripMenuItem.Text = "Gerencial - Investidor/Despesa/Saldo";
            this.acompanhamentoInvestidorToolStripMenuItem.Click += new System.EventHandler(this.acompanhamentoInvestidorToolStripMenuItem_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(265, 6);
            // 
            // investidoresToolStripMenuItem1
            // 
            this.investidoresToolStripMenuItem1.Name = "investidoresToolStripMenuItem1";
            this.investidoresToolStripMenuItem1.Size = new System.Drawing.Size(268, 22);
            this.investidoresToolStripMenuItem1.Tag = "17";
            this.investidoresToolStripMenuItem1.Text = "Investidores ";
            this.investidoresToolStripMenuItem1.Click += new System.EventHandler(this.investidoresToolStripMenuItem1_Click);
            // 
            // extratoPagamentoInvestidorToolStripMenuItem
            // 
            this.extratoPagamentoInvestidorToolStripMenuItem.Name = "extratoPagamentoInvestidorToolStripMenuItem";
            this.extratoPagamentoInvestidorToolStripMenuItem.Size = new System.Drawing.Size(268, 22);
            this.extratoPagamentoInvestidorToolStripMenuItem.Tag = "18";
            this.extratoPagamentoInvestidorToolStripMenuItem.Text = "Extrato Pagamento Investidor";
            this.extratoPagamentoInvestidorToolStripMenuItem.Click += new System.EventHandler(this.extratoPagamentoInvestidorToolStripMenuItem_Click);
            // 
            // cotasToolStripMenuItem
            // 
            this.cotasToolStripMenuItem.Name = "cotasToolStripMenuItem";
            this.cotasToolStripMenuItem.Size = new System.Drawing.Size(268, 22);
            this.cotasToolStripMenuItem.Tag = "23";
            this.cotasToolStripMenuItem.Text = "Cotas";
            this.cotasToolStripMenuItem.Click += new System.EventHandler(this.cotasToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(265, 6);
            // 
            // patrimôniosToolStripMenuItem
            // 
            this.patrimôniosToolStripMenuItem.Name = "patrimôniosToolStripMenuItem";
            this.patrimôniosToolStripMenuItem.Size = new System.Drawing.Size(268, 22);
            this.patrimôniosToolStripMenuItem.Tag = "19";
            this.patrimôniosToolStripMenuItem.Text = "Patrimônios";
            this.patrimôniosToolStripMenuItem.Click += new System.EventHandler(this.patrimôniosToolStripMenuItem_Click);
            // 
            // ajudaManualToolStripMenuItem
            // 
            this.ajudaManualToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.manualToolStripMenuItem,
            this.contatoToolStripMenuItem});
            this.ajudaManualToolStripMenuItem.Name = "ajudaManualToolStripMenuItem";
            this.ajudaManualToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.ajudaManualToolStripMenuItem.Text = "Ajuda";
            this.ajudaManualToolStripMenuItem.Click += new System.EventHandler(this.ajudaManualToolStripMenuItem_Click);
            // 
            // manualToolStripMenuItem
            // 
            this.manualToolStripMenuItem.Name = "manualToolStripMenuItem";
            this.manualToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.manualToolStripMenuItem.Text = "Manual";
            this.manualToolStripMenuItem.Click += new System.EventHandler(this.manualToolStripMenuItem_Click);
            // 
            // contatoToolStripMenuItem
            // 
            this.contatoToolStripMenuItem.Name = "contatoToolStripMenuItem";
            this.contatoToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.contatoToolStripMenuItem.Text = "Informações / Contato";
            this.contatoToolStripMenuItem.Click += new System.EventHandler(this.contatoToolStripMenuItem_Click);
            // 
            // pnlAtalho
            // 
            this.pnlAtalho.BackColor = System.Drawing.Color.LightGray;
            this.pnlAtalho.Controls.Add(this.button7);
            this.pnlAtalho.Controls.Add(this.button8);
            this.pnlAtalho.Controls.Add(this.button10);
            this.pnlAtalho.Controls.Add(this.button6);
            this.pnlAtalho.Controls.Add(this.button5);
            this.pnlAtalho.Controls.Add(this.button4);
            this.pnlAtalho.Controls.Add(this.button3);
            this.pnlAtalho.Controls.Add(this.button2);
            this.pnlAtalho.Controls.Add(this.button1);
            this.pnlAtalho.Controls.Add(this.label2);
            this.pnlAtalho.Controls.Add(this.label1);
            this.pnlAtalho.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlAtalho.Location = new System.Drawing.Point(0, 24);
            this.pnlAtalho.Name = "pnlAtalho";
            this.pnlAtalho.Size = new System.Drawing.Size(872, 49);
            this.pnlAtalho.TabIndex = 8;
            // 
            // button7
            // 
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.Location = new System.Drawing.Point(3, 5);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(54, 40);
            this.button7.TabIndex = 0;
            this.toolTip1.SetToolTip(this.button7, "Login/Lgout");
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.loginToolStripMenuItem1_Click);
            // 
            // button8
            // 
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.Image = ((System.Drawing.Image)(resources.GetObject("button8.Image")));
            this.button8.Location = new System.Drawing.Point(277, 5);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(54, 40);
            this.button8.TabIndex = 0;
            this.toolTip1.SetToolTip(this.button8, "Despesas por Etapa/Atividade");
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.despesaPorEtapaAtividadeToolStripMenuItem_Click);
            // 
            // button10
            // 
            this.button10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button10.Image = global::SGFOC.Properties.Resources.GráficoPricipal;
            this.button10.Location = new System.Drawing.Point(337, 5);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(54, 40);
            this.button10.TabIndex = 0;
            this.toolTip1.SetToolTip(this.button10, "Gráfico Principal");
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.gráficoPrincipalToolStripMenuItem_Click);
            // 
            // button6
            // 
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.Location = new System.Drawing.Point(391, 5);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(54, 40);
            this.button6.TabIndex = 0;
            this.toolTip1.SetToolTip(this.button6, "Backup(Cópia de Segurança)");
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.backupCópiaDeSegurançaToolStripMenuItem_Click);
            // 
            // button5
            // 
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(445, 5);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(54, 40);
            this.button5.TabIndex = 0;
            this.toolTip1.SetToolTip(this.button5, "Sair");
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(224, 5);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(54, 40);
            this.button4.TabIndex = 0;
            this.toolTip1.SetToolTip(this.button4, "Fornecedores");
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.forToolStripMenuItem_Click);
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(171, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(54, 40);
            this.button3.TabIndex = 0;
            this.toolTip1.SetToolTip(this.button3, "Investidores/Lançamentos Financeiros");
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.investidoresToolStripMenuItem_Click);
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(118, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(54, 40);
            this.button2.TabIndex = 0;
            this.toolTip1.SetToolTip(this.button2, "Cronograma/Etapa/Atividade");
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.cronogramaToolStripMenuItem_Click);
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(65, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(54, 40);
            this.button1.TabIndex = 0;
            this.toolTip1.SetToolTip(this.button1, "Obras");
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.ObraToolStripMenuItem_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(53, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "|";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(326, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "|";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "Arquivo de Backup|*.BAK";
            this.saveFileDialog1.RestoreDirectory = true;
            this.saveFileDialog1.Title = "Salva Backup (Cópia de Segurança)";
            // 
            // SGFOC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(872, 381);
            this.Controls.Add(this.pnlAtalho);
            this.Controls.Add(this.menuStrip2);
            this.ForeColor = System.Drawing.Color.Black;
            this.Location = new System.Drawing.Point(0, 0);
            this.Name = "SGFOC";
            this.Text = "6";
            this.Load += new System.EventHandler(this.DRProjetoMain_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.DRProjetoMain_FormClosed);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DRProjetoMain_FormClosing);
            this.Controls.SetChildIndex(this.menuStrip2, 0);
            this.Controls.SetChildIndex(this.pnlAtalho, 0);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.pnlAtalho.ResumeLayout(false);
            this.pnlAtalho.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ObraToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem sistemaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selecionarObraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem empresaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cronogramaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lançamentosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem despesasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem forToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem despesaPorEtapaAtividadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem investidoresToolStripMenuItem;
        private System.Windows.Forms.Panel pnlAtalho;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ToolStripMenuItem backupCópiaDeSegurançaToolStripMenuItem;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.ToolStripMenuItem gerencialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gráficoPrincipalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usuáriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem relatóriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem investidoresToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem acompanhamentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem acompanhamentoInvestidorToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem extratoPagamentoInvestidorToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem despesaPorEtapaAtividadeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem patrimônioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem patrimôniosToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem rendimentosMensalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem etapasAtividadesCadastradasToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem ajudaManualToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem conferenciaDeDespesasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cotasDaObraToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem cotasToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem manualToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contatoToolStripMenuItem;

    }
}

